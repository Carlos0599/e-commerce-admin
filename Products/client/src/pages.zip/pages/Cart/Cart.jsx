import style from "./Cart.module.css";
import CartItem from "../../components/Cart/CartItem";
import Navbar from "../../assets/navbar.png";
import Footer from "../../assets/footer.png";
import Summary from "../../components/Cart/Summary";
function Cart() {
  const items = [
    {
      id: 1,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope 1 ",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue.",

      unit: 10,
      quantity: 3,
      person: "Jonhalyn C. Gosssssssss",
    },
    {
      id: 2,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope 2",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue.",
      unit: 15,
      quantity: 1,
      person: "Jonhalyn C. Go",
    },
    {
      id: 3,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope 3",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
      unit: 20,
      quantity: 2,
      person: "Jonhalyn C. Go",
    },
  ];
  const getTotal = () => {
    let total = 0;

    items.map((item, key) => {
      total += item.unit * item.quantity;
    });
    return total;
  };
  return (
    <>
      <img src={Navbar} style={{ width: "100%" }} alt="" />
      <main className={`container ${style.cart}`}>
        <h1 className={style.cart__label}>Shopping Cart</h1>
        <div className={style.cart__labels}>
          <div className={style.cart__labels_product}>
            <input type="checkbox" className={style.cart__labels_checkbox} />
            <h4>Products</h4>
          </div>
          <h4>Unit Price</h4>
          <h4>Quantity</h4>
          <h4>Total Price</h4>
          <h4>Actions</h4>
        </div>
        {items.map((item, key) => {
          return <CartItem props={item} />;
        })}

        <Summary props={getTotal()} />
      </main>
      <img src={Footer} style={{ width: "100%" }} alt="" />
    </>
  );
}

export default Cart;
