import style from "./Checkout.module.css";
import Navbar from "../../assets/navbar.png";
import Footer from "../../assets/footer.png";
import gcash from "../../assets/gcash.png";
import banktransfer from "../../assets/banktransfer.jpg";
import paypal from "../../assets/paypal.png";
import CartItem from "../../components/Checkout/CartItem";
import { EditModal, OrderModal } from "../../components/Checkout/Modal";
import { useRef } from "react";

function Checkout() {
  const orderModalRef = useRef(null);
  const editModalRef = useRef(null);
  const items = [
    {
      id: 1,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope 1 ",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue.",

      unit: 10,
      quantity: 3,
      person: "Jonhalyn C. Gosssssssss",
    },
    {
      id: 2,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope 2",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue.",
      unit: 15,
      quantity: 1,
      person: "Jonhalyn C. Go",
    },
    {
      id: 3,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope 3",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
      unit: 20,
      quantity: 2,
      person: "Jonhalyn C. Go",
    },
  ];
  const getTotal = () => {
    let total = 0;

    items.map((item, key) => {
      total += item.unit * item.quantity;
    });
    return total;
  };
  return (
    <>
      <img src={Navbar} style={{ width: "100%" }} alt="" />
      <div className="container">
        <h2 className={style.checkout__title}>Check Out</h2>
      </div>

      <div className={style.checkout__details}>
        <div className={`container ${style.checkout__address}`}>
          <p>mapicon</p>
          <div>
            <h4>Delivery Address</h4>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum
              at aliquam consequatur dignissimos? Tenetur, quae nulla?{" "}
            </p>
          </div>
          <p
            className={style.checkout__address_edit}
            onClick={() => editModalRef.current.displayModal()}
          >
            Edit{" "}
          </p>
        </div>
      </div>
      <div className="container">
        <div className={style.cart__labels}>
          <div className={style.cart__labels_product}>
            <h4>Products Ordered</h4>
          </div>
          <h4>Unit Price</h4>
          <h4>Quantity</h4>
          <h4>Total Price</h4>
        </div>
        {items.map((item, key) => {
          return <CartItem props={item} />;
        })}

        <div className={style.checkout__payment}>
          <div className={style.checkout__payment_type}>
            <h3>Payment type</h3>
            <img src={gcash} alt="" />
            <img src={banktransfer} alt="" />
            <img src={paypal} alt="" />
          </div>

          <div className={style.checkout__payment_upload}>
            <h3>Upload Payment</h3>
            <p>Upload your Proof of Payment:</p>
            <label htmlFor="fileUpload">Choose file:</label>
            <input type="file" id="fileUpload" />
          </div>
        </div>
        <div className={style.checkout__total}>
          <h3>Total Payment:</h3>
          <h3 className={style.checkout__total_price}>P {getTotal()}</h3>
        </div>
        <div className={style.checkout__button}>
          <button onClick={() => orderModalRef.current.displayModal()}>
            Place Order
          </button>
        </div>
      </div>

      <img src={Footer} style={{ width: "100%" }} alt="" />
      <OrderModal ref={orderModalRef} />
      <EditModal ref={editModalRef} />
    </>
  );
}

export default Checkout;
