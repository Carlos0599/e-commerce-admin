function filtering(filter) {
  return filter;
}
export default filtering;
