function Carousel({ images }) {
  return <div>carousel</div>;
}

export default Carousel;
