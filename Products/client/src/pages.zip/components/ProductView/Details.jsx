import style from "./Details.module.css";
import Breadcrumbs from "./Breadcrumbs";
import Modal from "./Modal";
import { useRef, useState, useEffect } from "react";

function Details(props) {
  const modalRef = useRef(null);
  let [quantity, setQuantity] = useState(1);
  const [item, setitem] = useState([]);
  useEffect(() => {
    getItems();
  }, []);
  const items = [
    {
      id: 1,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope 1 ",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue.",
      person: "Jonhalyn C. Gosssssssss",
    },
    {
      id: 2,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope 2",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue.",
      person: "Jonhalyn C. Go",
    },
    {
      id: 3,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope 3",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
      person: "Jonhalyn C. Go",
    },
    {
      id: 4,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
      person: "Jonhalyn C. Go",
    },
    {
      id: 5,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
      person: "Jonhalyn C. Go",
    },
    {
      id: 6,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
      person: "Jonhalyn C. Go",
    },
    {
      id: 7,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
      person: "Jonhalyn C. Go",
    },
    {
      id: 8,
      image: "https://i.stack.imgur.com/y9DpT.jpg",
      name: "Mini Spy Scope",
      definition:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
      person: "Jonhalyn C. Go",
    },
  ];
  const getItems = () => {
    items.map((item, index) => {
      if (item.id == props.props) {
        setitem(item);
      }
    });
  };

  return (
    <div className={style.details}>
      <Breadcrumbs />
      <h1>{item.name}</h1>
      <div className={style.details__person}>
        <h4>Innovator/s:&nbsp;</h4>
        <p>{item.person}</p>
      </div>
      <p>{item.definition}</p>

      <div className={style.details__quantity}>
        <p>Quantity</p>
        <div className={style.details__quantity_buttons}>
          <button
            onClick={() => {
              if (quantity <= 1) {
                setQuantity(0);
              } else {
                setQuantity((quantity -= 1));
              }
            }}
          >
            -
          </button>
          <p>{quantity}</p>
          <button
            onClick={() => {
              setQuantity((quantity += 1));
            }}
          >
            +
          </button>
        </div>
      </div>

      <div className={style.details__buttons}>
        <button
        // onClick={() => {
        //   modalRef.current.displayModal();
        // }}
        >
          {" "}
          <a href="/cart"> Add to Cart</a>
        </button>
        <a href="/checkout">Buy Now</a>
      </div>
      <Modal ref={modalRef} props={item} />
    </div>
  );
}

export default Details;
