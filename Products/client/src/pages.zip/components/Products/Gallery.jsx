import style from "./Gallery.module.css";
import Item from "./Item";
import { useRef, useState, useEffect } from "react";
import productlist from "../ProductList";
import productBook from "../ProductBook";
import productSouvenirs from "../ProductSouvenirs";
import stylefilter from "./Filter.module.css";
function Gallery(props) {
  const [products, setProducts] = useState([]);
  const [holder, setholder] = useState("Recent");

  useEffect(() => {
    if (props.props == "books") {
      setProducts(productBook);
    } else if (props.props == "innovations") {
      setProducts(productlist);
    } else if (props.props == "souvenirs") {
      setProducts(productSouvenirs);
    }
  }, []);

  return (
    <>
      <div className="container">
        <div>
          <h2 className={stylefilter.filter__label}>{props.props}</h2>
          <p className={stylefilter.filter__result}>
            Showing <span className={stylefilter.filter__result_count}>1</span>{" "}
            result
          </p>
        </div>
      </div>
      <div className={stylefilter.filter}>
        <div className="container">
          <div className={stylefilter.filter__buttons}>
            <div className={stylefilter.filter__buttons_sort}>
              <p>Sort by</p>
              <button
                className={
                  holder == "Recent" ? stylefilter.filter__buttons_selected : ""
                }
                onClick={() => {
                  setholder("Recent");
                  console.log(products);
                }}
              >
                Recent
              </button>
              <button
                className={
                  holder == "Price" ? stylefilter.filter__buttons_selected : ""
                }
                onClick={() => {
                  setholder("Price");
                  console.log(products);
                }}
              >
                Price
              </button>
            </div>
            <div className={stylefilter.filter__buttons_paginate}>
              <p>1 / 1</p>
              <button>&lt;</button>
              <button>&gt;</button>
            </div>
          </div>
        </div>
      </div>
      <div className="container">
        <div className={style.gallery}>
          {holder == "Price"
            ? products
                .sort((a, b) => (a.unit > b.unit ? 1 : -1))
                .map((item, index) => (
                  <Item
                    key={index}
                    id={item.id}
                    image={item.image}
                    name={item.name}
                    person={item.person}
                  />
                ))
            : products
                .sort((a, b) => (a.id > b.id ? 1 : -1))
                .map((item, index) => (
                  <Item
                    key={index}
                    id={item.id}
                    image={item.image}
                    name={item.name}
                    person={item.person}
                  />
                ))}
        </div>
      </div>
    </>
  );
}

export default Gallery;
