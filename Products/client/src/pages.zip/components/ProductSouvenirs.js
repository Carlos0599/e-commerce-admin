const souvenirs = [
  {
    id: 1,
    image: "https://i.stack.imgur.com/y9DpT.jpg",
    name: "Mini Spy Souvenirs 1 ",
    definition:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue.",
    person: "Jonhalyn C. Gosssssssss",
  },
  {
    id: 2,
    image: "https://i.stack.imgur.com/y9DpT.jpg",
    name: "Mini Spy Scope 2",
    definition:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue.",
    person: "Jonhalyn C. Go",
  },
  {
    id: 3,
    image: "https://i.stack.imgur.com/y9DpT.jpg",
    name: "Mini Spy Scope 3",
    definition:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
    person: "Jonhalyn C. Go",
  },
  {
    id: 4,
    image: "https://i.stack.imgur.com/y9DpT.jpg",
    name: "Mini Spy Scope",
    definition:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
    person: "Jonhalyn C. Go",
  },
  {
    id: 5,
    image: "https://i.stack.imgur.com/y9DpT.jpg",
    name: "Mini Spy Scope",
    definition:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
    person: "Jonhalyn C. Go",
  },
  {
    id: 6,
    image: "https://i.stack.imgur.com/y9DpT.jpg",
    name: "Mini Spy Scope",
    definition:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
    person: "Jonhalyn C. Go",
  },
  {
    id: 7,
    image: "https://i.stack.imgur.com/y9DpT.jpg",
    name: "Mini Spy Scope",
    definition:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
    person: "Jonhalyn C. Go",
  },
  {
    id: 8,
    image: "https://i.stack.imgur.com/y9DpT.jpg",
    name: "Mini Spy Scope",
    definition:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec placerat sapien. Integer orci odio, ultricies nec consectetur sit amet, rhoncus eget risus. Phasellus ut ante semper mauris blandit varius. Proin tincidunt nibh tortor, sit amet ultrices ligula tincidunt eu. Cras nec dignissim erat. Curabitur nec ante eget ante sollicitudin elementum eget id tortor. Aenean quis ipsum volutpat purus pretium placerat sed eget sem. Suspendisse potenti. Duis posuere non ante at ullamcorper. Nullam eget maximus odio, rhoncus pellentesque augue",
    person: "Jonhalyn C. Go",
  },
];
export default souvenirs;
