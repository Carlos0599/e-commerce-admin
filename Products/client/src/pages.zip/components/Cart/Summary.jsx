import style from "./Summary.module.css";
function Summary(props) {
  return (
    <div className={`container ${style.summary}`}>
      <p>
        Total (6): <span className={style.summary__total}>₱ {props.props}</span>
      </p>
      <button className={style.summary__button}>Checkout</button>
    </div>
  );
}

export default Summary;
